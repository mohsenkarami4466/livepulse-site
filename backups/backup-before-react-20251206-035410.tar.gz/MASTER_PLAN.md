# 📋 برنامه کامل کارها - Master Plan

**تاریخ ایجاد:** 2024-12-05  
**وضعیت:** آماده برای اجرا

---

## ✅ کارهای تکمیل شده

1. ✅ **بررسی تقسیم فایل script.js** - تکمیل است
2. ✅ **حذف فایل script.js اضافی** - حذف شد (backup موجود است)
3. ✅ **رفع خطاهای Syntax** - تمام خطاها رفع شدند
4. ✅ **ایجاد config.js** - ایجاد شد و در فایل‌های globe استفاده شد
5. ✅ **جایگزینی console.* در فایل‌های globe** - 56 مورد تبدیل شد
6. ✅ **بهبود error handling در gold-map.js و geo-borders.js** - انجام شد

---

## 📋 کارهای باقی‌مانده

### 🔴 فاز 1: اصلاحات کد (قبل از React/Next.js)

#### 1.1 استفاده از CONFIG در سایر فایل‌ها
**اولویت:** بالا  
**زمان تخمینی:** 2-3 ساعت  
**وضعیت:** ⚠️ شروع نشده

**کارها:**
- [ ] `script-globes.js` - استفاده از CONFIG برای hardcoded values
  - [ ] Camera settings
  - [ ] Animation speeds
  - [ ] Marker sizes
  - [ ] Time intervals
- [ ] `script-ui.js` - استفاده از CONFIG برای UI settings
  - [ ] Breakpoints
  - [ ] Gaps
  - [ ] Animation durations
- [ ] `script-tools.js` - استفاده از CONFIG برای tool settings
  - [ ] Usage limits
  - [ ] Default values
- [ ] سایر فایل‌ها - بررسی و استفاده از CONFIG

---

#### 1.2 بهبود Error Handling در Async Functions
**اولویت:** بالا  
**زمان تخمینی:** 3-4 ساعت  
**وضعیت:** ⚠️ شروع شده (در gold-map.js و geo-borders.js)

**کارها:**
- [ ] `script-globes.js` - بررسی async functions
  - [ ] `loadWorldData()` - اگر وجود دارد
  - [ ] `fetchMarketData()` - اگر وجود دارد
  - [ ] سایر async functions
- [ ] `script-init.js` - بررسی async functions
  - [ ] `initializeLivePulse()` - بررسی async operations
  - [ ] سایر async functions
- [ ] سایر فایل‌ها - بررسی async functions
  - [ ] `globe-2d-maps.js`
  - [ ] `globe-panels-draggable.js`

**الگو:**
```javascript
async function example() {
    try {
        // کد async
        const response = await fetch('...');
        if (!response.ok) throw new Error('خطا');
        return await response.json();
    } catch (error) {
        const log = window.logger || { error: console.error };
        log.error('خطا در example:', error);
        if (window.errorHandler) {
            window.errorHandler.handleError(error, 'example');
        }
        throw error;
    }
}
```

---

#### 1.3 جلوگیری از Duplicate Event Listeners
**اولویت:** بالا  
**زمان تخمینی:** 2-3 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] `script-globes.js` - 39 مورد addEventListener
  - [ ] بررسی همه event listeners
  - [ ] اضافه کردن flag برای جلوگیری از duplicate
- [ ] `script-ui.js` - بررسی event listeners
  - [ ] بررسی همه event listeners
  - [ ] اضافه کردن flag برای جلوگیری از duplicate
- [ ] سایر فایل‌ها - بررسی event listeners
  - [ ] `globe-2d-maps.js`
  - [ ] `globe-panels-draggable.js`

**الگو:**
```javascript
// ✅ استفاده از flag
if (!element.hasAttribute('data-listener-attached')) {
    element.setAttribute('data-listener-attached', 'true');
    element.addEventListener('click', handler);
}
```

---

### 🟡 فاز 2: بهبودهای کد (قبل از React/Next.js)

#### 2.1 کاهش Code Duplication
**اولویت:** متوسط  
**زمان تخمینی:** 4-5 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] ایجاد کلاس پایه `BaseGlobe` برای کره‌ها
  - [ ] استخراج منطق مشترک از `financial-globe.js` و `resources-globe.js`
  - [ ] ایجاد کلاس پایه
  - [ ] Refactor کردن کلاس‌های موجود
- [ ] ایجاد utility functions مشترک
  - [ ] Helper functions برای event handling
  - [ ] Helper functions برای marker creation
  - [ ] Helper functions برای animation

---

#### 2.2 بهینه‌سازی Performance
**اولویت:** متوسط  
**زمان تخمینی:** 3-4 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] استفاده از `requestAnimationFrame` برای animations
  - [ ] بررسی animation loops
  - [ ] تبدیل به `requestAnimationFrame`
- [ ] استفاده از `debounce` برای resize events
  - [ ] اضافه کردن debounce utility
  - [ ] استفاده در resize handlers
- [ ] Cleanup مناسب event listeners
  - [ ] بررسی memory leaks
  - [ ] اضافه کردن cleanup functions

---

#### 2.3 بهبود مدیریت State
**اولویت:** متوسط  
**زمان تخمینی:** 2-3 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] بررسی state management فعلی
  - [ ] `appState` در `script-main.js`
  - [ ] `sharedGlobeData` در `globe-2d-maps.js`
  - [ ] State در کلاس‌ها
- [ ] ایجاد State Manager ساده (اختیاری)
  - [ ] یا استفاده از یک object مرکزی

---

### 🟢 فاز 3: کارهای شما (بعد از اصلاحات)

#### 3.1 تغییرات ظاهر (UI/UX)
**اولویت:** طبق نیاز شما  
**زمان تخمینی:** متغیر  
**وضعیت:** ⏳ منتظر شروع

**کارها:**
- [ ] تغییرات ظاهری
- [ ] بهبود UX
- [ ] Responsive design
- [ ] Animation improvements

---

#### 3.2 تغییرات منطق (Logic)
**اولویت:** طبق نیاز شما  
**زمان تخمینی:** متغیر  
**وضعیت:** ⏳ منتظر شروع

**کارها:**
- [ ] تغییرات منطق برنامه
- [ ] اضافه کردن features جدید
- [ ] بهبود عملکرد

---

#### 3.3 تبدیل به React
**اولویت:** بعد از اصلاحات  
**زمان تخمینی:** 2-3 هفته  
**وضعیت:** ⏳ منتظر شروع

**کارها:**
- [ ] Setup React project
- [ ] تبدیل Components
- [ ] State Management (Redux/Zustand)
- [ ] Routing (React Router)
- [ ] Testing

---

#### 3.4 تبدیل به Next.js
**اولویت:** بعد از React  
**زمان تخمینی:** 1-2 هفته  
**وضعیت:** ⏳ منتظر شروع

**کارها:**
- [ ] Setup Next.js project
- [ ] Server-Side Rendering (SSR)
- [ ] Static Site Generation (SSG)
- [ ] API Routes
- [ ] Optimization

---

## 📊 خلاصه برنامه

### فاز 1: اصلاحات کد (قبل از React/Next.js)
**زمان تخمینی:** 7-10 ساعت  
**اولویت:** بالا

1. ⚠️ استفاده از CONFIG در سایر فایل‌ها (2-3 ساعت)
2. ⚠️ بهبود Error Handling در Async Functions (3-4 ساعت)
3. ⚠️ جلوگیری از Duplicate Event Listeners (2-3 ساعت)

### فاز 2: بهبودهای کد (قبل از React/Next.js)
**زمان تخمینی:** 9-12 ساعت  
**اولویت:** متوسط

4. ⚠️ کاهش Code Duplication (4-5 ساعت)
5. ⚠️ بهینه‌سازی Performance (3-4 ساعت)
6. ⚠️ بهبود مدیریت State (2-3 ساعت)

### فاز 3: کارهای شما (بعد از اصلاحات)
**زمان تخمینی:** متغیر  
**اولویت:** طبق نیاز شما

7. ⏳ تغییرات ظاهر (UI/UX)
8. ⏳ تغییرات منطق (Logic)
9. ⏳ تبدیل به React (2-3 هفته)
10. ⏳ تبدیل به Next.js (1-2 هفته)

---

## 🎯 توصیه برنامه

### مرحله 1: فاز 1 (اصلاحات کد)
**زمان:** 1-2 روز  
**اولویت:** بالا

انجام فاز 1 کامل قبل از شروع کارهای شما:
- استفاده از CONFIG
- بهبود Error Handling
- جلوگیری از Duplicate Event Listeners

**نتیجه:** کد پایدار و آماده برای تغییرات شما

---

### مرحله 2: فاز 2 (بهبودهای کد) - اختیاری
**زمان:** 1-2 روز  
**اولویت:** متوسط

اگر زمان دارید، فاز 2 را انجام دهید:
- کاهش Code Duplication
- بهینه‌سازی Performance
- بهبود مدیریت State

**نتیجه:** کد بهینه و آماده برای React

---

### مرحله 3: کارهای شما
**زمان:** متغیر  
**اولویت:** طبق نیاز شما

بعد از فاز 1 (و اختیاری فاز 2):
- تغییرات ظاهر
- تغییرات منطق
- تبدیل به React
- تبدیل به Next.js

---

## 📝 نکات مهم

1. **فاز 1 ضروری است** - باید قبل از React/Next.js انجام شود
2. **فاز 2 اختیاری است** - می‌توانید بعد از React انجام دهید
3. **کارهای شما** - بعد از فاز 1 می‌توانید شروع کنید
4. **Backup موجود است** - `script.js.backup` برای مرجع

---

## ✅ چک‌لیست پیشرفت

### فاز 1:
- [x] استفاده از CONFIG در `script-globes.js` ✅ **تکمیل شد**
- [x] استفاده از CONFIG در `script-ui.js` ✅ **تکمیل شد**
- [x] استفاده از CONFIG در `script-tools.js` ✅ **تکمیل شد**
- [x] بهبود Error Handling در `script-globes.js` ✅ **تکمیل شد**
- [x] بهبود Error Handling در `script-init.js` ✅ **تکمیل شد**
- [x] جلوگیری از Duplicate Event Listeners در `script-globes.js` ✅ **تکمیل شد (موارد مهم)**
- [x] جلوگیری از Duplicate Event Listeners در `script-ui.js` ✅ **تکمیل شد (موارد مهم)**

### فاز 2:
- [x] بررسی Code Duplication در Globe Classes ✅ **گزارش ایجاد شد**
- [ ] ایجاد کلاس پایه `BaseGlobeThree` (در حال بررسی)
- [x] ایجاد utility functions مشترک ✅ **تکمیل شد**
- [x] بهینه‌سازی Performance ✅ **تکمیل شد (موارد مهم)**
- [x] بهبود مدیریت State ✅ **تکمیل شد**

### فاز 3:
- [ ] تغییرات ظاهر
- [ ] تغییرات منطق
- [ ] تبدیل به React
- [ ] تبدیل به Next.js

---

**آماده برای شروع!** 🚀

