# 📋 برنامه کامل کارها - Master Plan

**تاریخ ایجاد:** 2024-12-05  
**آخرین به‌روزرسانی:** 2024-12-05  
**وضعیت:** ✅ فاز 1 و 2 تکمیل شد - آماده برای React/Next.js Migration

---

## 📦 بک‌آپ

**بک‌آپ کامل قبل از React Migration:**
- مسیر: `backups/backup-before-react-YYYYMMDD-HHMMSS.tar.gz`
- شامل: تمام فایل‌های پروژه (به جز node_modules و .git)
- تاریخ: قبل از شروع React migration
- **نکته:** در صورت نیاز به rollback، از این بک‌آپ استفاده کنید.

**برای جزئیات کامل React/Next.js Migration:** به فایل `REACT_MIGRATION_PLAN.md` مراجعه کنید.

---

## ✅ کارهای تکمیل شده

1. ✅ **بررسی تقسیم فایل script.js** - تکمیل است
2. ✅ **حذف فایل script.js اضافی** - حذف شد (backup موجود است)
3. ✅ **رفع خطاهای Syntax** - تمام خطاها رفع شدند
4. ✅ **ایجاد config.js** - ایجاد شد و در فایل‌های globe استفاده شد
5. ✅ **جایگزینی console.* در فایل‌های globe** - 56 مورد تبدیل شد
6. ✅ **بهبود error handling در gold-map.js و geo-borders.js** - انجام شد

---

## 📋 کارهای باقی‌مانده

### 🔴 فاز 1: اصلاحات کد (قبل از React/Next.js)

#### 1.1 استفاده از CONFIG در سایر فایل‌ها
**اولویت:** بالا  
**زمان تخمینی:** 2-3 ساعت  
**وضعیت:** ⚠️ شروع نشده

**کارها:**
- [ ] `script-globes.js` - استفاده از CONFIG برای hardcoded values
  - [ ] Camera settings
  - [ ] Animation speeds
  - [ ] Marker sizes
  - [ ] Time intervals
- [ ] `script-ui.js` - استفاده از CONFIG برای UI settings
  - [ ] Breakpoints
  - [ ] Gaps
  - [ ] Animation durations
- [ ] `script-tools.js` - استفاده از CONFIG برای tool settings
  - [ ] Usage limits
  - [ ] Default values
- [ ] سایر فایل‌ها - بررسی و استفاده از CONFIG

---

#### 1.2 بهبود Error Handling در Async Functions
**اولویت:** بالا  
**زمان تخمینی:** 3-4 ساعت  
**وضعیت:** ⚠️ شروع شده (در gold-map.js و geo-borders.js)

**کارها:**
- [ ] `script-globes.js` - بررسی async functions
  - [ ] `loadWorldData()` - اگر وجود دارد
  - [ ] `fetchMarketData()` - اگر وجود دارد
  - [ ] سایر async functions
- [ ] `script-init.js` - بررسی async functions
  - [ ] `initializeLivePulse()` - بررسی async operations
  - [ ] سایر async functions
- [ ] سایر فایل‌ها - بررسی async functions
  - [ ] `globe-2d-maps.js`
  - [ ] `globe-panels-draggable.js`

**الگو:**
```javascript
async function example() {
    try {
        // کد async
        const response = await fetch('...');
        if (!response.ok) throw new Error('خطا');
        return await response.json();
    } catch (error) {
        const log = window.logger || { error: console.error };
        log.error('خطا در example:', error);
        if (window.errorHandler) {
            window.errorHandler.handleError(error, 'example');
        }
        throw error;
    }
}
```

---

#### 1.3 جلوگیری از Duplicate Event Listeners
**اولویت:** بالا  
**زمان تخمینی:** 2-3 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] `script-globes.js` - 39 مورد addEventListener
  - [ ] بررسی همه event listeners
  - [ ] اضافه کردن flag برای جلوگیری از duplicate
- [ ] `script-ui.js` - بررسی event listeners
  - [ ] بررسی همه event listeners
  - [ ] اضافه کردن flag برای جلوگیری از duplicate
- [ ] سایر فایل‌ها - بررسی event listeners
  - [ ] `globe-2d-maps.js`
  - [ ] `globe-panels-draggable.js`

**الگو:**
```javascript
// ✅ استفاده از flag
if (!element.hasAttribute('data-listener-attached')) {
    element.setAttribute('data-listener-attached', 'true');
    element.addEventListener('click', handler);
}
```

---

### 🟡 فاز 2: بهبودهای کد (قبل از React/Next.js)

#### 2.1 کاهش Code Duplication
**اولویت:** متوسط  
**زمان تخمینی:** 4-5 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] ایجاد کلاس پایه `BaseGlobe` برای کره‌ها
  - [ ] استخراج منطق مشترک از `financial-globe.js` و `resources-globe.js`
  - [ ] ایجاد کلاس پایه
  - [ ] Refactor کردن کلاس‌های موجود
- [ ] ایجاد utility functions مشترک
  - [ ] Helper functions برای event handling
  - [ ] Helper functions برای marker creation
  - [ ] Helper functions برای animation

---

#### 2.2 بهینه‌سازی Performance
**اولویت:** متوسط  
**زمان تخمینی:** 3-4 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] استفاده از `requestAnimationFrame` برای animations
  - [ ] بررسی animation loops
  - [ ] تبدیل به `requestAnimationFrame`
- [ ] استفاده از `debounce` برای resize events
  - [ ] اضافه کردن debounce utility
  - [ ] استفاده در resize handlers
- [ ] Cleanup مناسب event listeners
  - [ ] بررسی memory leaks
  - [ ] اضافه کردن cleanup functions

---

#### 2.3 بهبود مدیریت State
**اولویت:** متوسط  
**زمان تخمینی:** 2-3 ساعت  
**وضعیت:** ⚠️ نیاز به بررسی

**کارها:**
- [ ] بررسی state management فعلی
  - [ ] `appState` در `script-main.js`
  - [ ] `sharedGlobeData` در `globe-2d-maps.js`
  - [ ] State در کلاس‌ها
- [ ] ایجاد State Manager ساده (اختیاری)
  - [ ] یا استفاده از یک object مرکزی

---

### 🟢 فاز 3: تبدیل به React و Next.js

**استراتژی:** تبدیل تدریجی و مرحله‌ای با تست بعد از هر مرحله

#### 3.1 تبدیل به React (فاز 1)
**اولویت:** بالا  
**زمان تخمینی:** 20-30 ساعت (2-3 هفته)  
**وضعیت:** ⏳ آماده برای شروع

**مراحل:**
- [ ] **مرحله 1.1:** Setup React Project
- [ ] **مرحله 1.2:** تبدیل Layout و Navigation
- [ ] **مرحله 1.3:** تبدیل Views (صفحات)
- [ ] **مرحله 1.4:** تبدیل Cards و Indicators
- [ ] **مرحله 1.5:** تبدیل Globe Components
- [ ] **مرحله 1.6:** تبدیل Tools Components
- [ ] **مرحله 1.7:** تبدیل Modals و UI Components
- [ ] **مرحله 1.8:** تبدیل State Management
- [ ] **مرحله 1.9:** تبدیل Utilities و Helpers
- [ ] **مرحله 1.10:** Testing و Optimization

**برای جزئیات کامل:** به فایل `REACT_MIGRATION_PLAN.md` مراجعه کنید.

---

#### 3.2 تبدیل به Next.js (فاز 2)
**اولویت:** بعد از React  
**زمان تخمینی:** 10-15 ساعت (1-2 هفته)  
**وضعیت:** ⏳ منتظر تکمیل React

**مراحل:**
- [ ] **مرحله 2.1:** Setup Next.js Project
- [ ] **مرحله 2.2:** تبدیل به App Router
- [ ] **مرحله 2.3:** Server-Side Rendering (SSR)
- [ ] **مرحله 2.4:** Static Site Generation (SSG)
- [ ] **مرحله 2.5:** Optimization
- [ ] **مرحله 2.6:** Deployment Setup

**برای جزئیات کامل:** به فایل `REACT_MIGRATION_PLAN.md` مراجعه کنید.

---

### 🟡 فاز 4: کارهای شما (بعد از React/Next.js)

#### 4.1 تغییرات ظاهر (UI/UX)
**اولویت:** طبق نیاز شما  
**زمان تخمینی:** متغیر  
**وضعیت:** ⏳ منتظر تکمیل React/Next.js

**کارها:**
- [ ] تغییرات ظاهری
- [ ] بهبود UX
- [ ] Responsive design
- [ ] Animation improvements

---

#### 4.2 تغییرات منطق (Logic)
**اولویت:** طبق نیاز شما  
**زمان تخمینی:** متغیر  
**وضعیت:** ⏳ منتظر تکمیل React/Next.js

**کارها:**
- [ ] تغییرات منطق برنامه
- [ ] اضافه کردن features جدید
- [ ] بهبود عملکرد

---

## 📊 خلاصه برنامه

### فاز 1: اصلاحات کد (قبل از React/Next.js)
**زمان تخمینی:** 7-10 ساعت  
**اولویت:** بالا

1. ⚠️ استفاده از CONFIG در سایر فایل‌ها (2-3 ساعت)
2. ⚠️ بهبود Error Handling در Async Functions (3-4 ساعت)
3. ⚠️ جلوگیری از Duplicate Event Listeners (2-3 ساعت)

### فاز 2: بهبودهای کد (قبل از React/Next.js)
**زمان تخمینی:** 9-12 ساعت  
**اولویت:** متوسط

4. ⚠️ کاهش Code Duplication (4-5 ساعت)
5. ⚠️ بهینه‌سازی Performance (3-4 ساعت)
6. ⚠️ بهبود مدیریت State (2-3 ساعت)

### فاز 3: تبدیل به React و Next.js
**زمان تخمینی:** 30-45 ساعت (3-5 هفته)  
**اولویت:** بالا

7. ⏳ تبدیل به React (20-30 ساعت - 2-3 هفته)
8. ⏳ تبدیل به Next.js (10-15 ساعت - 1-2 هفته)

### فاز 4: کارهای شما (بعد از React/Next.js)
**زمان تخمینی:** متغیر  
**اولویت:** طبق نیاز شما

9. ⏳ تغییرات ظاهر (UI/UX)
10. ⏳ تغییرات منطق (Logic)

---

## 🎯 توصیه برنامه

### مرحله 1: فاز 1 (اصلاحات کد)
**زمان:** 1-2 روز  
**اولویت:** بالا

انجام فاز 1 کامل قبل از شروع کارهای شما:
- استفاده از CONFIG
- بهبود Error Handling
- جلوگیری از Duplicate Event Listeners

**نتیجه:** کد پایدار و آماده برای تغییرات شما

---

### مرحله 2: فاز 2 (بهبودهای کد) - اختیاری
**زمان:** 1-2 روز  
**اولویت:** متوسط

اگر زمان دارید، فاز 2 را انجام دهید:
- کاهش Code Duplication
- بهینه‌سازی Performance
- بهبود مدیریت State

**نتیجه:** کد بهینه و آماده برای React

---

### مرحله 3: تبدیل به React و Next.js
**زمان:** 3-5 هفته  
**اولویت:** بالا

بعد از فاز 1 و 2:
- تبدیل به React (2-3 هفته)
- تبدیل به Next.js (1-2 هفته)

**نکته:** تبدیل تدریجی و مرحله‌ای با تست بعد از هر مرحله

### مرحله 4: کارهای شما
**زمان:** متغیر  
**اولویت:** طبق نیاز شما

بعد از React/Next.js:
- تغییرات ظاهر
- تغییرات منطق

---

## 📝 نکات مهم

1. ✅ **فاز 1 و 2 تکمیل شد** - کد آماده برای React/Next.js است
2. **بک‌آپ:** قبل از شروع React migration، بک‌آپ کامل گرفته شد
3. **استراتژی:** تبدیل تدریجی و مرحله‌ای با تست بعد از هر مرحله
4. **Documentation:** تمام مراحل در `REACT_MIGRATION_PLAN.md` مستند شده است
5. **Backup موجود است:** 
   - `script.js.backup` برای مرجع
   - `backups/backup-before-react-*.tar.gz` برای rollback

---

## ✅ چک‌لیست پیشرفت

### فاز 1:
- [x] استفاده از CONFIG در `script-globes.js` ✅ **تکمیل شد**
- [x] استفاده از CONFIG در `script-ui.js` ✅ **تکمیل شد**
- [x] استفاده از CONFIG در `script-tools.js` ✅ **تکمیل شد**
- [x] بهبود Error Handling در `script-globes.js` ✅ **تکمیل شد**
- [x] بهبود Error Handling در `script-init.js` ✅ **تکمیل شد**
- [x] جلوگیری از Duplicate Event Listeners در `script-globes.js` ✅ **تکمیل شد (موارد مهم)**
- [x] جلوگیری از Duplicate Event Listeners در `script-ui.js` ✅ **تکمیل شد (موارد مهم)**

### فاز 2:
- [x] بررسی Code Duplication در Globe Classes ✅ **گزارش ایجاد شد**
- [ ] ایجاد کلاس پایه `BaseGlobeThree` (در حال بررسی)
- [x] ایجاد utility functions مشترک ✅ **تکمیل شد**
- [x] بهینه‌سازی Performance ✅ **تکمیل شد (موارد مهم)**
- [x] بهبود مدیریت State ✅ **تکمیل شد**

### فاز 3: تبدیل به React
- [ ] مرحله 1.1: Setup React Project
- [ ] مرحله 1.2: تبدیل Layout و Navigation
- [ ] مرحله 1.3: تبدیل Views (صفحات)
- [ ] مرحله 1.4: تبدیل Cards و Indicators
- [ ] مرحله 1.5: تبدیل Globe Components
- [ ] مرحله 1.6: تبدیل Tools Components
- [ ] مرحله 1.7: تبدیل Modals و UI Components
- [ ] مرحله 1.8: تبدیل State Management
- [ ] مرحله 1.9: تبدیل Utilities و Helpers
- [ ] مرحله 1.10: Testing و Optimization

### فاز 4: تبدیل به Next.js
- [ ] مرحله 2.1: Setup Next.js Project
- [ ] مرحله 2.2: تبدیل به App Router
- [ ] مرحله 2.3: Server-Side Rendering (SSR)
- [ ] مرحله 2.4: Static Site Generation (SSG)
- [ ] مرحله 2.5: Optimization
- [ ] مرحله 2.6: Deployment Setup

### فاز 5: کارهای شما
- [ ] تغییرات ظاهر
- [ ] تغییرات منطق

---

## 📚 فایل‌های Documentation

1. **MASTER_PLAN.md** - این فایل: برنامه کامل کارها
2. **REACT_MIGRATION_PLAN.md** - برنامه دقیق تبدیل به React/Next.js (16 مرحله)
3. **MIGRATION_STATUS.md** - وضعیت فعلی migration
4. **WORK_PROGRESS.md** - گزارش پیشرفت کارها
5. **CODE_DUPLICATION_REPORT.md** - گزارش duplicate code
6. **AGENT_CONTEXT.md** - Context برای agent بعدی

---

## 🚀 شروع React Migration

**برای شروع:** به فایل `REACT_MIGRATION_PLAN.md` مراجعه کنید و از مرحله 1.1 شروع کنید.

**بک‌آپ:** `backups/backup-before-react-20251206-035410.tar.gz` (1.3 MB)

**استراتژی:** تبدیل تدریجی و مرحله‌ای با تست بعد از هر مرحله

**آماده برای شروع!** 🚀

