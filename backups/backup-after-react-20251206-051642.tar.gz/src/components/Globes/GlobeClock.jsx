import React, { useEffect, useRef } from 'react'
import { logger } from '../../utils'
import './GlobeClock.css'

function GlobeClock() {
  const containerRef = useRef(null)
  const wrapperRef = useRef(null)

  useEffect(() => {
    const log = window.logger || { info: console.log, warn: console.warn, error: console.error }
    
    // استفاده از کد موجود برای globe clock
    if (typeof window !== 'undefined' && window.initGlobe) {
      // اگر initGlobe وجود دارد، از آن استفاده کن
      const timer = setTimeout(() => {
        if (window.initGlobe) {
          window.initGlobe()
          log.info('GlobeClock: initGlobe called')
        }
      }, 100)
      
      // تنظیم موقعیت Globe Clock
      if (typeof window !== 'undefined' && window.updateGlobePosition) {
        const positionTimer = setTimeout(() => {
          if (window.updateGlobePosition) {
            window.updateGlobePosition()
            log.info('GlobeClock: updateGlobePosition called')
          }
        }, 200)
        
        // تنظیم موقعیت در resize
        const handleResize = () => {
          if (window.updateGlobePosition) {
            window.updateGlobePosition()
          }
        }
        
        window.addEventListener('resize', handleResize)
        
        return () => {
          clearTimeout(timer)
          clearTimeout(positionTimer)
          window.removeEventListener('resize', handleResize)
        }
      }
      
      return () => clearTimeout(timer)
    }
  }, [])

  return (
    <div 
      className="globe-clock-wrapper" 
      id="globeClockWrapper"
      ref={wrapperRef}
      style={{ 
        display: 'block',
        visibility: 'visible',
        opacity: 1,
        position: 'fixed',
        left: '8px',
        zIndex: 998
      }}
    >
      <div className="utc-clock-ring" id="utcClockRing">
        {/* ساعت‌های UTC توسط JS ساخته می‌شوند */}
      </div>
      <div 
        id="globeContainer" 
        ref={containerRef}
        title="کلیک کنید برای نقشه جهانی"
        onClick={(e) => {
          // استفاده از handler موجود
          if (typeof window !== 'undefined' && window.handleSmallGlobeClick) {
            window.handleSmallGlobeClick(e)
          }
        }}
        onTouchEnd={(e) => {
          // استفاده از handler موجود
          if (typeof window !== 'undefined' && window.handleSmallGlobeClick) {
            window.handleSmallGlobeClick(e)
          }
        }}
      ></div>
    </div>
  )
}

export default GlobeClock

