import React from 'react'
import Header from '../Header/Header'
import BottomNavigation from '../BottomNavigation/BottomNavigation'
import GlobeClock from '../Globes/GlobeClock'
import './Layout.css'

function Layout({ children }) {
  return (
    <div className="layout">
      <Header />
      {/* Globe Clock - در همه صفحات نمایش داده می‌شود */}
      <GlobeClock />
      <main className="layout-main">
        {children}
      </main>
      <BottomNavigation />
    </div>
  )
}

export default Layout

